# Bug-Tracker-System
An  application that tracks the assignment, status, and progress of issues related  to  a  project. 
